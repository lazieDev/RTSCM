<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 <link href="css/styles.css" rel="stylesheet">
 <script type="text/javascript" src="js/html2CSV.js" ></script>
<script type="text/javascript" src="jquery-1.8.2.js"></script>
    <script type="text/javascript" src="js/jszip.js"></script>
    <script type="text/javascript" src="js/FileSaver.js"></script>
    <script type="text/javascript" src="js/excel-gen.js"></script>
    <script type="text/javascript" src="js/demo.page.js"></script>

     <link href="jquery.dataTables.min.css" rel="stylesheet" />
<style>

.search-container {
	margin-right: 120px;
  float: right;
}

input[type=number] {
	 border: 1px solid #ccc;
  padding: 10px;
  margin-top: 8px;
  font-size: 17px;
  }

.search-container button {
  float: right;
  padding: 10px;
  margin-top: 8px;
  margin-right: 17px;
  background: #ddd;
  font-size: 17px;
  border: none;
  cursor: pointer;
}

.search-container button:hover {
  background: #ccc;
}

@media screen and (max-width: 600px) {
  .topnav .search-container {
    float: none;
  }
  input[type=text],.search-container button {
    float: none;
    display: block;
    text-align: left;
    width: 100%;
    margin: 0;
    padding: 24px;
  }
  .topnav input[type=text] {
    border: 1px solid #ccc;  
  }
}
</style>
 <script>

  $(document).ready(function() {
    $('#basic_table').DataTable( {
        dom: 'Bfrtip',
        buttons: ['copy', 'csv', 'excel', 'pdf', 'print']
    } );
} );
    </script>
    <script>
function myFunction() {
  var input, filter, table, tr, td, i;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("basic_table");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>
</head>
<body>
	<?php
include 'config.php';

if(!empty($_GET['status'])){
    switch($_GET['status']){
        case 'succ':
            $statusMsgClass = 'alert-success';
            $statusMsg = 'Members data has been inserted successfully.';
            break;
        case 'err':
            $statusMsgClass = 'alert-danger';
            $statusMsg = 'Some problem occurred, please try again.';
            break;
        case 'invalid_file':
            $statusMsgClass = 'alert-danger';
            $statusMsg = 'Please upload a valid CSV file.';
            break;
        default:
            $statusMsgClass = '';
            $statusMsg = '';
    }
}
?>
<nav class="navbar navbar-inverse">
  <div class="container-fluid" style="padding: 20px; color: white;">
    <div class="navbar-header">
     <h1> RTSCM</h1>
    </div>
   
  </div>
</nav>
<div class="container-fluid">
  <div class="jumbotron">
    <h3>CONFIGURATION</h3> 
  </div>
  <div class="search-container">
    <form action="search.php" method="post">
     <input type="number" id="myInput" onkeyup="myFunction()" placeholder="Search for id.." name="search" autocomplete="off"/>
      <button type="submit"><i class="fa fa-search"></i></button>
    </form>
  </div>
</div>
<div class="container-fluid" style="background-color: white;">

  <div class="row" style="margin-top: 10px;padding: 10px;" >
<div class="col-sm-3" style="border: 2px solid grey;
    border-radius: 5px;background-color: cyan;padding: 30px;">
    <h2 style="padding-bottom: 10px;">Enter details</h2>
	<form action="insert.php" method="post">
  <div class="form-group">
    <label for="id">id:</label>
    <input type="number" class="form-control" name="id" autocomplete="off">
  </div>
  <div class="form-group">
    <label for="sname">sname:</label>
    <input type="text" class="form-control" name="sname" autocomplete="off">
  </div>
  <div class="form-group">
    <label for="year">year:</label>
    <input type="number" class="form-control" name="year" autocomplete="off">
  </div>
  <div class="form-group">
    <label for="weight">weight:</label>
    <input type="number" class="form-control" name="wei" autocomplete="off">
  </div>
  <div class="form-group">
    <label for="purpose">purpose:</label>
    <input type="text" class="form-control" name="pur" autocomplete="off">
  </div>
  <div align="center">
  <button type="submit" class="btn btn-primary" >Submit</button>
</div>
</form> 
</div>
<div class="col-sm-8" style="border: 2px solid grey;
    border-radius: 5px;padding: 30px;margin-left: 10px;">
    <?php if(!empty($statusMsg)){
        echo '<div class="alert '.$statusMsgClass.'">'.$statusMsg.'</div>';
    } ?>
	<div class="table-responsive"> 
		<h3 style="padding-bottom: 20px;">Satellite Details</h3>
<div class="panel panel-default">
        <div class="panel-heading">
            Members list
            <a href="javascript:void(0);" onclick="$('#importFrm').slideToggle();">Import Members</a>
        </div>
        <div class="panel-body">
            <form action="import.php" method="post" enctype="multipart/form-data" id="importFrm">
                <input type="file" name="file" />
                <input type="submit" class="btn btn-primary" name="importSubmit" value="IMPORT">
            </form>
	<table class="table table-striped"  style="padding-top: 10px;" id="basic_table">
    <thead id="example1">
      <tr>
        <th>ID</th>
        <th>SATELLITE NAME</th>
        <th>YEAR</th>
        <th>WEIGHT</th>
        <th>PURPOSE</th>
      </tr>
    </thead>
    <tbody id="example1">
    <?php
    $query = $db->query("SELECT * FROM basic ORDER BY id DESC");
	if($query->fetchArray() > 0){ 
	while($row = $query->fetchArray()){ 
	?>
      <tr>
        <td><a href="" style="color: blue;" class="btn btn-info"><?php print($row['id']); ?></a></td>
        <td><?php print($row['sname']); ?></td>
        <td><?php print($row['year']); ?></td>
        <td><?php print($row['weight']); ?></td>
        <td><?php print($row['purpose']); ?></td>
      </tr>
      <?php } }else{ ?>
                    <tr><td colspan="5">No member(s) found.....</td></tr>
                    <?php } ?>
    </tbody>
  </table>
</div>
<button id="generate-excel-basic" class="btn btn-outline-primary">Generate Excel</button>
</div>
</div>
</div>
</div>

</div>
 <footer>
        <div class="splitter"></div>
        <ul>
            <li>
                <div class="icon" data-icon="E"></div>
                <div class="text">
                    <h4>About</h4>
                    <div>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin tristique justo eu sollicitudin pretium. Nam scelerisque arcu at dui porttitor, non viverra sapien pretium. Nunc nec dignissim nunc. Sed eget est purus. Sed convallis, metus in dictum feugiat, odio orci rhoncus metus. <a href="#">Read more</a></div>
                </div>
            </li>
            <li>
                <div class="icon" data-icon="a"></div>
                <div class="text">
                    <h4>Archive</h4>
                    <div>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin tristique justo eu sollicitudin pretium. Nam scelerisque arcu at dui porttitor, non viverra sapien pretium. Nunc nec dignissim nunc. Sed eget est purus. Sed convallis, metus in dictum feugiat, odio orci rhoncus metus. <a href="#">Read more</a></div>
                </div>
            </li>
            <li>
                <div class="icon" data-icon="s"></div>
                <div class="text">
                    <h4>Cloud</h4>
                    <div>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin tristique justo eu sollicitudin pretium. Nam scelerisque arcu at dui porttitor, non viverra sapien pretium. Nunc nec dignissim nunc. Sed eget est purus. Sed convallis, metus in dictum feugiat, odio orci rhoncus metus. <a href="#">Read more</a></div>
                </div>
            </li>
        </ul>

        <div class="bar">
            <div class="bar-wrap">
                <ul class="links">
                    <li><a href="#">Home</a></li>
                    <li><a href="#">License</a></li>
                    <li><a href="#">Contact Us</a></li>
                    <li><a href="#">Advertise</a></li>
                    <li><a href="#">About</a></li>
                </ul>

                <div class="social">
                    <a href="#" class="fb">
                        <span data-icon="f" class="icon"></span>
                        <span class="info">
                            <span class="follow">Become a fan Facebook</span>
                            <span class="num">9,999</span>
                        </span>
                    </a>

                    <a href="#" class="tw">
                        <span data-icon="T" class="icon"></span>
                        <span class="info">
                            <span class="follow">Follow us Twitter</span>
                            <span class="num">9,999</span>
                        </span>
                    </a>

                    <a href="#" class="rss">
                        <span data-icon="R" class="icon"></span>
                        <span class="info">
                            <span class="follow">Subscribe RSS</span>
                            <span class="num">9,999</span>
                        </span>
                    </a>
                </div>
                <div class="clear"></div>
                <div class="copyright">&copy;  2014 All Rights Reserved</div>
            </div>
        </div>
    </footer>
</body>

</html> 